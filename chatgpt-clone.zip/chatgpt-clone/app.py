import os
import openai
import gradio as gr
import time
from log import logger

#if you have OpenAI API key as an environment variable, enable the below
#openai.api_key = os.getenv("OPENAI_API_KEY")

#if you have OpenAI API key as a string, enable the below
openai.api_key = "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"

start_sequence = "\nAI:"
restart_sequence = "\nHuman: "

prompt = "The following is a conversation with an AI assistant. The assistant is helpful, creative, clever, and very friendly.\n\nHuman: Hello, who are you?\nAI: I am an AI created by OpenAI. How can I help you today?\nHuman: "

def openai_create(prompt, retry_count=0):
    try:
        response = openai.Completion.create(
        model="text-davinci-003",
        prompt=prompt,
        temperature=0.9,
        max_tokens=1500,
        top_p=1,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        stop=[" Human:", " AI:"]
        )
        res_content = response.choices[0]["text"].strip().rstrip("<|im_end|>")
        logger.info("[OPEN_AI] reply={}".format(res_content))
        return res_content
    except openai.error.RateLimitError as e:
        if retry_count < 1:
            time.sleep(5)
            logger.warning("[OPEN_AI] RateLimit exceed, 第{}次重试".format(retry_count + 1))
            return openai_create(prompt, retry_count + 1)
        else:
            return "提问太快啦，请休息一下再问我吧"
    except Exception as e:
         # unknown exception
        logger.exception(e)
        return "请再问我一次吧"


def chatgpt_clone(input, history):
    history = history or []
    # s = list(sum(history, ()))
    # s.append(input)
    logger.info("[OPEN_AI] query={}".format(input))
    # history_length = judgment_history_length(s)
    # if history_length > 2500:
    #     s.pop(0)
    # inp = ' '.join(s)
    # output = openai_create(inp)
    output = openai_create(input)
    history.append((input, output))
    return history, history                 # history, history

# def judgment_history_length(history):
#     length = 0
#     for str in history:
#         length += len(str.encode())
#     return length


block = gr.Blocks()
with block:
    gr.Markdown("""<h1><center>ChatGPT 测试</center></h1>""")
    chatbot = gr.Chatbot()
    message = gr.Textbox(placeholder=prompt)
    state = gr.State()
    submit = gr.Button("发送")
    submit.click(chatgpt_clone, inputs=[message, state], outputs=[chatbot, state])

block.launch(debug = True)
